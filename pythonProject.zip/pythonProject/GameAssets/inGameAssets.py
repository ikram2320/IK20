items_list = [
    {
        "name" : "Couteau"
    },
{
        "name" : "AK-47"
    },
{
        "name" : "épée"
    },
{
        "name" : "potion de vie"
    },
{
        "name" : "potion revigorante"
    },
{
        "name" : "pistolet"
    },
{
        "name" : "silencieux"
    },
{
        "name" : "Beretta"
    },
{
        "name" : "Coupe-Coupe"
    },
{
        "name" : "Tonçonneuse"
    },
{
        "name" : "Chargeur AK-47"
    },{
        "name" : "Arbalette"
    },{
        "name" : "Arc"
    },{
        "name" : "Flèches"
    },{
        "name" : "Flèche empoisonnée"
    },{
        "name" : "Grenade"
    },{
        "name" : "lance-flamme"
    },{
        "name" : "Pierre"
    },{
        "name" : "Cailloux"
    },{
        "name" : "dague"
    },{
        "name" : "nokia 530"
    },{
        "name" : "Infinix hot S"
    },{
        "name" : "Tecno Pop 2"
    },{
        "name" : "Carte sim"
    },{
        "name" : "potion d'invincibilité"
    },{
        "name" : "filet découpant"
    },{
        "name" : "Lame"
    },{
        "name" : "Ciseaux"
    },{
        "name" : "Bâton"
    },{
        "name" : "livre"
    },{
        "name" : "Lance-pierre"
    },{
        "name" : "Brique"
    },{
        "name" : "Bazooka"
    },{
        "name" : "nokia 45"
    },{
        "name" : "livre 85"
    },{
        "name" : "Bazooka96"
    },{
        "name" : "potion explosive35"
    },{
        "name" : "lance-grenade"
    },{
        "name" : "Poison"
    },{
        "name" : "Spark4"
    },{
        "name" : "Smart5"
    },{
        "name" : "Huawei y5"
    },{
        "name" : "Huawei P30"
    },{
        "name" : "Couteau54"
    },{
        "name" : "Lance"
    },{
        "name" : "Nountchakou"
    },{
        "name" : "Tchakatou"
    },{
        "name" : "moto"
    },{
        "name" : "Voiture"
    },{
        "name" : "Mitrailleuse"
    },{
        "name" : "Pain"
    },{
        "name" : "Viande"
    },{
        "name" : "Poulet"
    },{
        "name" : "Poisson"
    },{
        "name" : "Bouteille"
    },{
        "name" : "Gourde"
    },{
        "name" : "bille"
    },{
        "name" : "Tecno Pop"
    },{
        "name" : "Infinix note 7"
    },{
        "name" : "Tecno L85"
    },{
        "name" : "Tcno pouvoir8"
    },{
        "name" : "Smart 78"
    },{
        "name" : "Motorola Z"
    },{
        "name" : "Xiaomi"
    },{
        "name" : "Redmi note7"
    },{
        "name" : "Redmi"
    },{
        "name" : "Colle"
    },{
        "name" : "Pot de fleur"
    },{
        "name" : "fleur guérissante"
    },{
        "name" : "grillade"
    },{
        "name" : "cape d'invincibilité"
    },{
        "name" : "pile plate"
    },{
        "name" : "pile 20V"
    },{
        "name" : "Batterie"
    },{
        "name" : "peau de banane"
    },
{
        "name" : "bidon"
    },{
        "name" : "Killer 20"
    },{
        "name" : "Killer"
    },{
        "name" : "Jus de fruits"
    },{
        "name" : "Orange"
    },{
        "name" : "Mangue"
    },{
        "name" : "Ananas"
    },{
        "name" : "Bible"
    },{
        "name" : "glace"
    },{
        "name" : "Gomme"
    },{
        "name" : "Crayon"
    },{
        "name" : "Stylo"
    },{
        "name" : "Règle plate"
    },{
        "name" : "pièce d'or"
    },{
        "name" : "Gari"
    },{
        "name" : "Manioc"
    },{
        "name" : "igname"
    },{
        "name" : "treuil"
    },{
        "name" : "poulie"
    },{
        "name" : "Table"
    },{
        "name" : "chaise"
    },{
        "name" : "Oeuf de dragon"
    },{
        "name" : "Oeuf de canne"
    },{
        "name" : "Oeuf de poule"
    },{
        "name" : "Couteau78"
    },{
        "name" : "Couteau56"
    },{
        "name" : "Iphone5"
    },{
        "name" : "Iphone6"
    },{
        "name" : "Iphone7"
    },{
        "name" : "Iphone8"
    },{
        "name" : "Iphone9"
    },{
        "name" : "Couteau11"
    },{
        "name" : "Iphone12"
    },{
        "name" : "Iphone10"
    },{
        "name" : "Batterie120V"
    },{
        "name" : "Grosse pile60V"
    },{
        "name" : "carte arduino"
    },{
        "name" : "Pièce de monnaie"
    },{
        "name" : "Casquette"
    },{
        "name" : "Poids"
    },{
        "name" : "Hp56"
    },{
        "name" : "Zozor"
    },
]

beasts_list = [
    {
        "name": "Infinity Monster",
        "level": 5
},
{
        "name": "Infinity Monster",
        "level": 6
},
{
        "name": "Infinity Monster",
        "level": 7
},
{
        "name": "Infinity Monster",
        "level": 8
},
{
        "name": "Infinity Monster",
        "level": 9
},
{
        "name": "Infinity Monster",
        "level": 10
},
    {
        "name": "Dragon",
        "level": 10
},
{
        "name": "Dragon",
        "level": 11
},
{
        "name": "Dragon",
        "level": 12
},
{
        "name": "Dragon",
        "level": 13
},
{
        "name": "Dragon",
        "level": 14
},
{
        "name": "Dragon",
        "level": 15
},
    {
        "name": "Shingeki no kyojin",
        "level": 15
},
    {
        "name": "Shingeki no kyojin",
        "level": 16
},
    {
        "name": "Shingeki no kyojin",
        "level": 17
},
    {
        "name": "Shingeki no kyojin",
        "level": 18
},
    {
        "name": "Shingeki no kyojin",
        "level": 19
},
{
        "name": "Fateur de trouble",
         "level": 20
},
    {
        "name": "Fateur de trouble",
         "level": 21
},
{
        "name": "Fauteur de trouble",
         "level": 22
},
{
        "name": "Fauteur de trouble",
         "level": 23
},
{
        "name": "Fauteur de trouble",
         "level": 24
},
{
        "name": "Fauteur de trouble",
         "level": 25
},
    {
        "name": "titan collosal",
        "level": 40
},
{
        "name": "titan collosal",
        "level": 41
},
{
        "name": "titan collosal",
        "level": 42
},
{
        "name": "titan collosal",
        "level": 43
},
{
        "name": "titan collosal",
        "level": 44
},
{
        "name": "titan collosal",
        "level": 45
},
    {
        "name": "Sukuna",
       "level": 60
},
{
        "name": "Sukuna",
       "level": 61
},
{
        "name": "Sukuna",
       "level": 62
},
{
        "name": "Sukuna",
       "level": 63
},
{
        "name": "Sukuna",
       "level": 64
},
{
        "name": "Sukuna",
       "level": 65
},
    {
    "name": "Mort vivant",
    "level": 25
},
  {
    "name": "Mort vivant",
    "level": 26
},
  {
    "name": "Mort vivant",
    "level": 27
},
  {
    "name": "Mort vivant",
    "level": 28
},
  {
    "name": "Mort vivant",
    "level": 29
},
  {
    "name": "Mort vivant",
    "level": 30
},

    {
    "name": "Loup",
    "level": 20
},
{
    "name": "John Wick",
    "level": 80
},
    {
    "name": "John Wick",
    "level": 81
},
{
    "name": "John Wick",
    "level": 82
},
{
    "name": "John Wick",
    "level": 83
},
{
    "name": "John Wick",
    "level": 84
},
{
    "name": "John Wick",
    "level": 85
},

    {
    "name": "troll",
    "level": 25
},
    {
    "name": "Goblin",
    "level": 10
},
{
    "name": "Goblin",
    "level": 11
},
{
    "name": "Goblin",
    "level": 12
},
    {
    "name": "Goblin",
    "level": 13
},
{
    "name": "Goblin",
    "level": 14
},
{
    "name": "Goblin",
    "level": 15
},

    {
    "name": "Moloss",
    "level": 40
},
 {
    "name": "Moloss",
    "level": 41
},
 {
    "name": "Moloss",
    "level": 42
},
 {
    "name": "Moloss",
    "level": 43
},
 {
    "name": "Moloss",
    "level": 44
},
 {
    "name": "Moloss",
    "level": 45
},
    {
    "name": "Dadju",
    "level": 50
},
{
    "name": "Dadju",
    "level": 51
},
{
    "name": "Dadju",
    "level": 52
},
{
    "name": "Dadju",
    "level": 53
},
{
    "name": "Dadju",
    "level": 54
},
{
    "name": "Dadju",
    "level": 55
},
    {
    "name": "Djamiou",
    "level": 70
},
{
    "name": "Djamiou",
    "level": 71
},
{
    "name": "Djamiou",
    "level": 72
},
{
    "name": "Djamiou",
    "level": 73
},
{
    "name": "Djamiou",
    "level": 74
},
{
    "name": "Djamiou",
    "level": 75
},
    {
    "name": "Moufidath",
    "level": 65
},
{
    "name": "Moufidath",
    "level": 64
},
{
    "name": "Moufidath",
    "level": 66
},
{
    "name": "Moufidath",
    "level": 67
},
{
    "name": "Moufidath",
    "level": 68
},
{
    "name": "Moufidath",
    "level": 69
},
    {
    "name": "Bomberman",
    "level": 40
},    {
    "name": "Démon",
    "level": 30
},
    {
    "name": "Olo",
    "level": 60
},
{
    "name": "Olo",
    "level": 61
},
{
    "name": "Olo",
    "level": 62
},
{
    "name": "Olo",
    "level": 63
},
{
    "name": "Olo",
    "level": 64
},
{
    "name": "Olo",
    "level": 65
},

{
    "name": "Bougre",
    "level": 18
},    {
    "name": "",
    "level": 9
},    {
    "name": "Kenn",
    "level": 90
},    {
    "name": "Wolverine",
    "level": 90
},
{
    "name": "Wolverine",
    "level": 91
},
{
    "name": "Wolverine",
    "level": 92
},
{
    "name": "Wolverine",
    "level": 93
},
{
    "name": "Wolverine",
    "level": 94
},
{
    "name": "Wolverine",
    "level": 95
},
    {
    "name": "Alex Mecer",
    "level": 85
},
    {
    "name": "Alex Mecer",
    "level": 86
},
    {
    "name": "Alex Mecer",
    "level": 87
},
    {
    "name": "Alex Mecer",
    "level": 88
},
    {
    "name": "Alex Mecer",
    "level": 89
},
{
    "name": "Alex Mecer",
    "level": 85
},
{
    "name": "Pacman",
    "level": 14
},
{
    "name": "Bob l'éponge",
    "level": 95
},
{
    "name": "Bob l'éponge",
    "level": 96
},
{
    "name": "Bob l'éponge",
    "level": 97
},
{
    "name": "Bob l'éponge",
    "level": 98
},
{
    "name": "Bob l'éponge",
    "level": 99
},
{
    "name": "Bob l'éponge",
    "level": 99
},
{
    "name": "Bayern Munich",
    "level": 81
},
{
    "name": "Bayern Munich",
    "level": 82
},

{
    "name": "Bayern Munich",
    "level": 83
},

{
    "name": "Bayern Munich",
    "level": 84
},

{
    "name": "Bayern Munich",
    "level": 85
},

{
    "name": "Barcelone",
    "level": 26
},
{
    "name": "Barcelone",
    "level": 27
},
{
    "name": "Barcelone",
    "level": 28
},
{
    "name": "Barcelone",
    "level": 29
},
{
    "name": "Barcelone",
    "level": 25
},
    {
    "name": "fourmis géantes",
    "level": 1
},
{
    "name": "fourmis géantes",
    "level": 5
},
{
    "name": "fourmis géantes",
    "level": 4
},
{
    "name": "fourmis géantes",
    "level": 3
},
{
    "name": "fourmis géantes",
    "level": 2
},
{
    "name": "Jack L'évantreur",
    "level": 30
},
  {
    "name": "Jack L'évantreur",
    "level": 31
},
{
    "name": "Jack L'évantreur",
    "level": 32
},{
    "name": "Jack L'évantreur",
    "level": 33
},{
    "name": "Jack L'évantreur",
    "level": 34
},
{
    "name": "Jack L'évantreur",
    "level": 35
},
{
    "name": "Tigre",
    "level": 75
},
{
    "name": "Gargouille",
    "level": 7
},
{
    "name": "Lion",
    "level": 40
},
{
    "name": "lutin",
    "level": 17
},
      {
    "name": "Singe",
    "level": 36
},

{
    "name": "Singe",
    "level": 37
},
{
    "name": "Singe",
    "level": 38
},
{
    "name": "Singe",
    "level": 39
},
{
    "name": "Singe",
    "level": 40
},


]

Boss_beast = {
        "name": "Behemoth",
        "level": 101,
}
