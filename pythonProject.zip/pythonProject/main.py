
# Game scenario
import sys, os
from GameAssets.items import Item, ItemType
from GameAssets.characters import Beast, Player, critical_boost
from GameAssets.utilities import help, prompt_to_move, get_possible_beast, get_beast_stats, get_player_stats, prompt_to_attack
from GameAssets.inGameAssets import beasts_list, items_list, Boss_beast
import random

# Defining Globals

Joueur = Player("Bob", 700, 200, 7)   # -->  Le joueur se définit Ici
Boss = Beast(Boss_beast["name"], 10000, 300, 450, Boss_beast["level"])  # -->  Le Boss se définit Ici
GAME_FINISHED: bool = False       # Ne pas modifier


def Menu():
    print("1: Create new game")
    print("2: Load Game")
    print("3: About")
    print("4: Exit")

    try:
        Choix = int(input(">  "))
        if Choix == 1:
            PlayGame()
        elif Choix == 2:
            load_game()
        elif Choix == 3:
            about()
        else:
            Exit()

    except Exception:
        print("Enter should be number 1, 2, 3 or 4 ")
        Exit()


def Exit():
    print("Game will Exit now")
    print("Console sleeps for 5s before exiting")
    sys.exit(0)


def PlayGame():
    print("TODO Lancer le jeu")
    ask_name()
    while not game_is_finished() :
        # description("test")
        if (prompt_to_move(Joueur) % 4 == 0):
            i = random.choice([0,1,1,1,0])        # Actuellement, il y a 40% de chances(Bête) et 60% (Item)
            if i == 0:
                B = random.choice(get_possible_beast(Joueur))
                print("Done!")
                if enter_combat_mode(Joueur, B):
                    Joueur.raise_EXP(B)
                    print("You won !")
                    get_player_stats(Joueur)
                else:
                    print("Unfortunately, our hero died !")
                    get_player_stats(Joueur)
                    GAME_FINISHED = True
                    Menu() # Return to menu

            elif i == 1:
                 # It's an item
                Found_Item()


def load_game():
    try:
        game_file = open("game.sav", mode="r")
        saves = game_file.readline()
        Joueur.position = {
            "North": saves.split(",")[0],
            "East": saves.split(",")[1],
            "West": saves.split(",")[2],
            "South": saves.split(",")[3]
            }
        Joueur.LVL = int(saves.split(",")[4])
        for itcount in range(int(saves.split(",")[5])):
            Joueur.Inventory.append(random.choice(items_list))
    except:
        pass
    PlayGame()


def save_game():
    game_file = open("game.sav", mode="w")
    """
    Player Position  0,1,2,3,
    Player lvl  4,
    Player InventoryCount  5,
    """
    saves = str.format("{0},{1},{2},{3},{4},{5}", Joueur.position.get("North"),
                     Joueur.position.get("East"), Joueur.position.get("West"),
                     Joueur.position.get("South"), Joueur.LVL, len(Joueur.Inventory))
    game_file.write(saves)


def about():
    help()
    print(""""\n \n \n""")
    Menu()


def game_is_finished():
    return GAME_FINISHED

def ask_name():
    name = str(input("Votre nom>  "))
    if name == "":
        print("Welcome Bob")
    else:
        print("Welcome {0}!".format(name))
        Joueur.name = name


def enter_combat_mode(P: Player, B: Beast):
    print("Combat Mode activated!")
    print("a Lvl {0} {1} suddenly surged on the forest".format(B.LVL, B.name))
    print("[S T A T S]")
    get_beast_stats(B)
    while P.isAlive() and B.isAlive():
        prompt_to_attack(P, B)
        B.attack(P)
    return P.isAlive()


def Found_Item():
    get_random_item = random.choice(items_list)
    i = Item(get_random_item.get("name"),
             random.choice([ItemType.healing_potion, ItemType.attack_boost, ItemType.defense_boost]),
             boost_points= random.choice(critical_boost), description=''
             )
    # Add to Inventory
    Joueur.add2Inventory(i)
    print("Vous avez trouvé un nouvel item:")
    print(str.format("nom: {0} \nboost: +{1}% {2} \n", i.name, i.boost_points, i.Type.name.split('_')[0]))


if __name__ == '__main__':
    Menu()
